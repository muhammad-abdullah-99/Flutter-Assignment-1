import 'dart:html';

import 'package:flutter/material.dart';

class ChatsTab extends StatelessWidget {
  const ChatsTab({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: const [
          ListTile(
            tileColor: Colors.grey,
            leading: CircleAvatar(
              backgroundColor: Colors.blue,
            ),
            title: Text('John'),
            subtitle: Text('Hi'),
            trailing: Text("11:00 p.m"),
          ),
          ListTile(
            tileColor: Colors.grey,
            leading: CircleAvatar(
              backgroundColor: Colors.brown,
            ),
            title: Text('John'),
            subtitle: Text('There'),
            trailing: Text("2:00 p.m"),
          ),
          ListTile(
            tileColor: Colors.grey,
            leading: CircleAvatar(
              backgroundColor: Colors.purple,
            ),
            title: Text('John'),
            subtitle: Text('Salam...'),
            trailing: Text("12:00 a.m"),
          ),
          ListTile(
            tileColor: Colors.grey,
            leading: CircleAvatar(
              backgroundColor: Colors.orange,
            ),
            title: Text('John'),
            subtitle: Text('hello...'),
            trailing: Text("12:00 a.m"),
          ),
          ListTile(
            tileColor: Colors.grey,
            leading: CircleAvatar(
              backgroundColor: Colors.lightGreenAccent,
            ),
            title: Text('John'),
            subtitle: Text('hey...'),
            trailing: Text("12:00 a.m"),
          ),
          ListTile(
            tileColor: Colors.grey,
            leading: CircleAvatar(backgroundColor: Colors.red),
            title: Text('John'),
            subtitle: Text('hi...'),
            trailing: Text("12:00 a.m"),
          ),
          ListTile(
            tileColor: Colors.grey,
            leading: CircleAvatar(
              backgroundColor: Colors.amber,
            ),
            title: Text('John'),
            subtitle: Text('salam...'),
            trailing: Text("12:00 a.m"),
          ),
          ListTile(
            tileColor: Colors.grey,
            leading: CircleAvatar(backgroundColor: Colors.cyan),
            title: Text('John'),
            subtitle: Text('hello...'),
            trailing: Text("12:00 a.m"),
          ),
          ListTile(
            tileColor: Colors.grey,
            leading: CircleAvatar(
              backgroundColor: Colors.greenAccent,
            ),
            title: Text('John'),
            subtitle: Text('hello...'),
            trailing: Text("12:00 a.m"),
          ),
          ListTile(
            tileColor: Colors.grey,
            leading: CircleAvatar(backgroundColor: Colors.yellowAccent),
            title: Text('John'),
            subtitle: Text('How Are You'),
            trailing: Text("12:00 a.m"),
          ),
          ListTile(
            tileColor: Colors.grey,
            leading: CircleAvatar(backgroundColor: Colors.black38),
            title: Text('John'),
            subtitle: Text('hi...'),
            trailing: Text("12:00 a.m"),
          ),
        ],
      ),
    );
  }
}
